CREATE TABLE EMPLOYEE1 (
    eid INT,
    fname VARCHAR(50),
    lname VARCHAR(50),
    age INT,
    salary INT NULL,
    dept VARCHAR(20),
    doj DATE
);

INSERT INTO EMPLOYEE1 (eid, fname, lname, age, salary, dept, doj) VALUES
(1, 'rajeev', 'sukla', 23, 12000, '.net', '2011-10-23'),
(2, 'sowmya', 'kumari', 23, 19000, 'db', '2010-11-13'),
(3, 'kishore', 'kumar', 27, 36000, 'android', '2011-10-16'),
(4, 'abimanyu', 'biswal', 22, NULL, 'android', '2010-02-20'),
(5, 'soni', 'kumar', 24, 21800, '.net', '2009-06-21'),
(6, 'anu', '_singh', 22, 12000, 'db', '2010-10-23'),
(7, '_dinesh', 'moh%anty', 23, 15000, '.net', '2009-08-26'),
(8, 'nishala', '_kumari', 22, 18000, 'db', '2008-07-19');

SELECT * FROM EMPLOYEE1;
SELECT eid, fname, lname, age, salary, dept, doj FROM EMPLOYEE1;
SELECT CONCAT(fname, lname) AS fullname, age FROM EMPLOYEE1;

SELECT * FROM EMPLOYEE1 ORDER BY fname;
SELECT * FROM EMPLOYEE1 ORDER BY fname DESC;
SELECT * FROM EMPLOYEE1 ORDER BY lname ASC, fname DESC;

SELECT DISTINCT lname FROM EMPLOYEE1;
SELECT DISTINCT fname, age FROM EMPLOYEE1;

SELECT * FROM EMPLOYEE1 LIMIT 3;
SELECT * FROM EMPLOYEE1 LIMIT 5,2;
SELECT CONCAT(fname,' ',lname) AS fullname, age FROM EMPLOYEE1 ORDER BY salary DESC LIMIT 3;

SELECT * FROM EMPLOYEE1 WHERE salary > 20000;
SELECT * FROM EMPLOYEE1 WHERE salary BETWEEN 15000 AND 25000;
SELECT * FROM EMPLOYEE1 WHERE salary NOT BETWEEN 15000 AND 25000;
SELECT * FROM EMPLOYEE1 WHERE salary IN (15000, 21800, 36000);
SELECT * FROM EMPLOYEE1 WHERE salary NOT IN (15000, 21800, 36000);
SELECT * FROM EMPLOYEE1 WHERE salary IS NULL;
SELECT * FROM EMPLOYEE1 WHERE salary IS NOT NULL;

SELECT * FROM EMPLOYEE1 WHERE fname LIKE 'a%';
SELECT * FROM EMPLOYEE1 WHERE fname LIKE '%a';
SELECT * FROM EMPLOYEE1 WHERE fname LIKE '_a%';
SELECT * FROM EMPLOYEE1 WHERE fname LIKE '%a%';
SELECT * FROM EMPLOYEE1 WHERE lname LIKE '%a_';
SELECT * FROM EMPLOYEE1 WHERE fname NOT LIKE '%a';

INSERT INTO EMPLOYEE1 VALUES (9,'giri','babu',27,18000,'.net','2014-06-24');
UPDATE EMPLOYEE1 SET fname='rice', lname='paul' WHERE eid=9;
DELETE FROM EMPLOYEE1 WHERE eid=9;

SELECT AVG(salary) AS average_salary FROM EMPLOYEE1;
SELECT MIN(salary) AS min_salary FROM EMPLOYEE1;
SELECT MAX(salary) AS max_salary FROM EMPLOYEE1;
SELECT SUM(salary) AS total_salary FROM EMPLOYEE1;
SELECT COUNT(*) FROM EMPLOYEE1;
SELECT COUNT(*) FROM EMPLOYEE1 WHERE dept='db';

SELECT dept, COUNT(*) AS total_employees FROM EMPLOYEE1 GROUP BY dept;
SELECT dept, AVG(salary) AS avg_salary FROM EMPLOYEE1 GROUP BY dept HAVING AVG(salary) > 15000;
SELECT * FROM EMPLOYEE1 WHERE salary > (SELECT salary FROM EMPLOYEE1 WHERE eid=4);
SELECT * FROM EMPLOYEE1 WHERE salary > (SELECT AVG(salary) FROM EMPLOYEE1 WHERE dept='db');
SELECT * FROM EMPLOYEE1 WHERE salary BETWEEN (SELECT MIN(salary) FROM EMPLOYEE1 WHERE dept='db') AND (SELECT MAX(salary) FROM EMPLOYEE1 WHERE dept='.net');

SELECT e1.salary FROM EMPLOYEE1 e1 WHERE 1 = (SELECT COUNT(*) FROM EMPLOYEE1 e2 WHERE e2.salary > e1.salary);

ALTER TABLE EMPLOYEE1 ADD mgr_id INT;
SELECT e1.fname AS employee, e2.fname AS manager FROM EMPLOYEE1 e1 JOIN EMPLOYEE1 e2 ON e1.mgr_id = e2.eid;

CREATE INDEX idx_salary ON EMPLOYEE1(salary);

CREATE VIEW v_employee AS SELECT * FROM EMPLOYEE1;
SELECT * FROM v_employee;

DELIMITER //
CREATE PROCEDURE getEmployees()
BEGIN
    SELECT * FROM EMPLOYEE1;
END //
DELIMITER ;
CALL getEmployees();

CREATE TABLE patient (
    pid INT,
    fname VARCHAR(50),
    lname VARCHAR(50),
    age INT,
    bg VARCHAR(10)
);

INSERT INTO patient (pid, fname, lname, age, bg) VALUES
(1, 'madhava', 'reddy', 45, 'o+ve'),
(2, 'abhinav', 'bandra', 45, 'o-ve'),
(4, 'hari', 'kiran', 60, 'b-ve'),
(3, 'madhava', 'kiran', 52, 'o+ve'),
(5, 'veena', 'kumari', 42, NULL),
(6, 'k_iran', 'kumar', 39, 'b-ve'),
(2, 'abhinav', 'bandra', 45, 'o-ve'),
(7, 'mahes%h', 'nambootri', 36, 'b+ve'),
(8, 'rahul', 'kumar', 46, 'b-ve'),
(9, 'bharat', 'kumar', 56, 'b-ve');

SELECT * FROM patient;
SELECT pid, fname, lname, age, bg FROM patient;
SELECT CONCAT(fname, ' ', lname) AS fullname, pid, age FROM patient;

SELECT CONCAT(fname,' ',lname) AS fullname, age+2 AS age_after_2_years FROM patient;

SELECT * FROM patient ORDER BY age;
SELECT * FROM patient ORDER BY age DESC;
SELECT * FROM patient ORDER BY lname ASC, fname DESC;

SELECT CONCAT(fname,lname) AS fullname, age FROM patient ORDER BY age;
SELECT fname, lname, bg FROM patient ORDER BY bg DESC;

SELECT DISTINCT fname, age FROM patient;
SELECT DISTINCT age, bg FROM patient;
SELECT DISTINCT fname, age, bg FROM patient ORDER BY bg DESC;

SELECT fname, lname, age FROM patient LIMIT 3;
SELECT * FROM patient ORDER BY age DESC LIMIT 3;

SELECT * FROM patient WHERE age > 45;
SELECT * FROM patient WHERE age BETWEEN 40 AND 50;
SELECT * FROM patient WHERE age >= 40 AND age <= 50;
SELECT * FROM patient WHERE age > 40 AND bg != 'o+ve';

SELECT * FROM patient WHERE bg IS NOT NULL;
SELECT * FROM patient WHERE age IN (42,36,60);
SELECT * FROM patient WHERE age NOT IN (42,36,60);

SELECT * FROM patient WHERE fname LIKE 'm%';
SELECT CONCAT(fname,' ',lname) AS fullname FROM patient WHERE lname LIKE '%i';
SELECT * FROM patient WHERE lname LIKE '%a_';
SELECT * FROM patient WHERE fname LIKE '%r__';
SELECT * FROM patient WHERE fname LIKE '%i%';

INSERT INTO patient VALUES (10,'ahana','kumar',78,'o+ve');
INSERT INTO patient VALUES (11,'silli','suresh',81,NULL);

UPDATE patient SET fname='raja',
    lname='raveender',
    age=66,
    bg='o-ve'
WHERE pid=10;

UPDATE patient
SET fname='meena',
    lname='kumari'
WHERE pid=11;

DELETE FROM patient WHERE pid = 2 LIMIT 1;
ALTER TABLE patient ADD PRIMARY KEY (pid);
DELETE FROM patient WHERE pid IN (10,11);

SELECT MIN(age) AS youngest FROM patient;
SELECT MAX(age) AS eldest FROM patient;
SELECT SUM(age) AS total_age FROM patient;
SELECT AVG(age) AS avg_age FROM patient;

SELECT fname FROM patient WHERE age = (SELECT MIN(age) FROM patient);

SELECT bg, COUNT(*) AS total FROM patient GROUP BY bg;
SELECT bg, AVG(age) AS avg_age FROM patient GROUP BY bg HAVING AVG(age) > 45;

SELECT * FROM patient WHERE age > (SELECT age FROM patient WHERE pid=3 LIMIT 1);
SELECT * FROM patient WHERE bg = (SELECT bg FROM patient WHERE pid=6 LIMIT 1);
SELECT * FROM patient WHERE age NOT IN (SELECT age FROM patient WHERE pid IN (1,3,9));

SELECT p1.* FROM patient p1 WHERE 3 =(SELECT COUNT(*) FROM patient p2 WHERE p2.age > p1.age);

CREATE VIEW vpatient AS SELECT * FROM patient;

SELECT * FROM vpatient;

CREATE INDEX idx_age ON patient(age);
